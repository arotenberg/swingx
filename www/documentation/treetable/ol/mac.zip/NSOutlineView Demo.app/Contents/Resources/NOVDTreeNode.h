//
//  NOVDTreeNode.h
//  NSOutlineView Demo
//
//  Created by David John Burrowes on 4/26/05.
//  Copyright 2005 Sun Microsystems, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NOVDTreeNode : NSObject {
	NSString* myName;
	NSMutableArray* myChildren;
}

- init;
- (NSArray*) children;
- (BOOL) hasChildren;
- (void) addChild: (NOVDTreeNode*) child;
- (void) deleteChildren;
- (NSString*) name;
- (void) setName: (NSString*) name;

@end
