//
//  NOVDController.h
//  NSOutlineView Demo
//
//  Created by David John Burrowes on 4/26/05.
//  Copyright 2005 Sun Microsystems, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NOVDController : NSObject {
    IBOutlet id allowColumnReorderingCheckbox;
    IBOutlet id allowColumnResizingCheckbox;
    IBOutlet id allowColumnSelectionCheckbox;
    IBOutlet id allowEmptySelectionCheckbox;
    IBOutlet id allowMultipleSelectionCheckbox;
    IBOutlet id backgroundColorWell;
    IBOutlet id cornerButton;
    IBOutlet id cornerMenu;
    IBOutlet id gridColorWell;
    IBOutlet id horizontalGridLinesCheckbox;
    IBOutlet id horizontalIntercellSpacingField;
    IBOutlet id indentationField;
    IBOutlet id indentMarkersFollowCellCheckbox;
    IBOutlet id numberOfColumnsField;
    IBOutlet id outlineView;
    IBOutlet id rowHeightField;
    IBOutlet id sortedColumnCheckbox;
    IBOutlet id useAlternatingRowCheckbox;
    IBOutlet id verticalGridLinesCheckbox;
    IBOutlet id verticalIntercellSpacingField;
}
- (IBAction)allowColumnReordering:(id)sender;
- (IBAction)allowColumnResizing:(id)sender;
- (IBAction)allowColumnSelection:(id)sender;
- (IBAction)allowColumnSorting:(id)sender;
- (IBAction)allowEmptySelection:(id)sender;
- (IBAction)allowMultipleSelection:(id)sender;
- (IBAction)changeBackgroundColor:(id)sender;
- (IBAction)changeGridDetails:(id)sender;
- (IBAction)changeIndentation:(id)sender;
- (IBAction)changeIndentMarkersFollowing:(id)sender;
- (IBAction)changeIntercellSpacing:(id)sender;
- (IBAction)changeNumberOfColumns:(id)sender;
- (IBAction)changeRowHeight:(id)sender;
- (IBAction)displayCornerMenu:(id)sender;
- (IBAction)useAlternatingRowColors:(id)sender;

@end
